<?php

namespace App\Filament\Resources\MCQResource\Pages;

use App\Filament\Resources\MCQResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMCQ extends CreateRecord
{
    protected static string $resource = MCQResource::class;
}
