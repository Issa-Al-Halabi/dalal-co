<x-filament-widgets::widget>
    <x-filament::section>
        {{ $this->form }}
    </x-filament::section>
</x-filament-widgets::widget>
