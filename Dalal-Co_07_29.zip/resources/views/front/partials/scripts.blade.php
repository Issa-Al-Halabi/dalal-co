<script src="{{ asset('front-assets/js/compressed.js') }}"></script>
<script src="{{ asset('front-assets/js/main.js') }}"></script>
<script src="{{ asset('front-assets/js/switcher.js') }}"></script>
