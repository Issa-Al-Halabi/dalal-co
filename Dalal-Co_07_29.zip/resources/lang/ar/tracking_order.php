<?php

return [
    'completed_tasks' => 'المراحل المنجزة',
    'working_on_tasks' => 'المرحلة التي يتم العمل عليها',
    'uncompleted_tasks' => 'المراحل غير المنجزة',
    'additional_paid_services' => 'خدمات إضافية مأجورة',
    'cost_of_the_maid_ticket' => 'حجز تذكرة سفر , قيمة التذكرة الخاصة بالعاملة هي',
    'sp' => 'ل.س',
    'delivery_service' => 'خدمة التوصيل إلى مطار دمشق الدولي هي',
];
