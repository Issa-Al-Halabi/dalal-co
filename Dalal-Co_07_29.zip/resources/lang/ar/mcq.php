<?php

return [
   
"Register your request for your service"=>"تسجيل طلبك لخدمتك",
"Register a care service request"=>"تسجيل طلب خدمة رعاية",
"Do you need elderly care?"=>"هل تحتاج إلى رعاية مسن؟",
"yes"=>"نعم",

"no"=>"لا",
"Do you need childcare?"=>"هل تحتاج إلى رعاية أطفال؟",
"State the number of children:"=>"اذكر عدد الأطفال: ",
"Do you need a nursing course?"=>"هل تحتاج إلى دورة تمريض؟",
"Home work experience?"=>"خبرة بأعمال المنزل؟",
"Recepion?"=>"استقبال؟"

];
