<?php

return [
    'completed_tasks' => 'Completed tasks',
    'working_on_tasks' => 'Working on tasks',
    'uncompleted_tasks' => 'Uncompleted tasks',
    'additional_paid_services' => 'Additional paid services',
    'cost_of_the_maid_ticket' => 'Book a travel ticket, the cost of the Maid’s ticket is',
    'sp' => 'SP',
    'delivery_service' => 'The delivery service to Damascus International Airport is',
];
