<?php

return [
   
"Register your request for your service"=>"Register your request for your service  ",
"Register a care service request"=>"Register a care service request",
"Do you need elderly care?"=>"Do you need elderly care?",
"yes"=>"yes",

"no"=>"no",
"Do you need childcare?"=>"Do you need childcare?",
"State the number of children:"=>"State the number of children: ",
"Do you need a nursing course?"=>"Do you need a nursing course?",
"Home work experience?"=>"Home work experience?",
"Recepion?"=>"Recepion?"

];
